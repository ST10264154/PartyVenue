
package partyvenue;
import javax.swing.JOptionPane;

public class PartyVenue {

    public static void main(String[] args) {
    
        String userInput = JOptionPane.showInputDialog(null, "Enter Age");
        int age = Integer.parseInt(userInput);

        if(age >= 18 && age <= 35) {
          JOptionPane.showMessageDialog(null, "Eligible to enter party venue");
        }
        else if(age < 18){
            JOptionPane.showMessageDialog(null, "Not eligible to enter party venue, too young");
        }
        else{
              JOptionPane.showMessageDialog(null, "Not eligible to enter party venue, too old");
         }
        
        String gender = JOptionPane.showInputDialog(null, "Enter Gender");
        
        if (gender.equals("female")) {
             JOptionPane.showMessageDialog(null, "Free entry");
             JOptionPane.showInputDialog(null, "Enter number of guests");
             JOptionPane.showMessageDialog(null, "Price to be paid: R0" );
        } 
        else if (gender.equals("male")) {
            userInput = JOptionPane.showInputDialog(null, "Enter number of guests");
            int numGuests = Integer.parseInt(userInput);
            int price = numGuests * 10; 
            JOptionPane.showMessageDialog(null, "Price to be paid: R" + price);
        } 
        else {
            JOptionPane.showMessageDialog(null, "Invalid gender input");
        }
    }
}

